import "./App.css";
import DeckOfCards from "./components/deck-of-cards/deck-of-cards";

function App() {
    return (
        <DeckOfCards />
    );
}

export default App;
