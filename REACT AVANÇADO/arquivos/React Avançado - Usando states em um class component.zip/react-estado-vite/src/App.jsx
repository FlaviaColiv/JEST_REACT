import "./App.css";
import Panel from "./components/panel/panel";

function App() {
    return (
        <Panel />
    );
}

export default App;
