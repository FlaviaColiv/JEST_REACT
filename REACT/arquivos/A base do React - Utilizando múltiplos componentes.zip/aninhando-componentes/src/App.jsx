import Cards from "./components/cards/cards";

function App() {

  return (
      <Cards />
  );
}

export default App
