import Button from "./components/button/button"

function App() {

  return (
      <>
          <Button label="Baixar CV"/>
          <Button />
      </>
  );
}

export default App
