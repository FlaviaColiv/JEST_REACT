import Card from "./components/card/card"
//import Button from "./components/button/button"

function App() {

  return (
    <>
      <Card />
      <Card />
      <Card />
    </>
  )
}

export default App
